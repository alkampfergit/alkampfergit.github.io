namespace LinqTest
{
    partial class FirstTestDataContext
    {
    }
}
