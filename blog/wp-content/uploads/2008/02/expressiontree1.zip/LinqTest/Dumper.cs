﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Windows.Forms;

namespace LinqTest
{
    public partial class Dumper : Form
    {
        private DumpVisitor visitor = new DumpVisitor();
        public Dumper()
        {
            InitializeComponent();
            gbDynamic.Height = 0;
            listBox1.DataSource = CreateExpressionList();
        }

        private List<KeyValuePair<String, Expression>> CreateExpressionList()
        {
            List<KeyValuePair<String, Expression>> exps =
                new List<KeyValuePair<string, Expression>>();
            Expression<Func<Int32, Int32>> e1 = (Int32 a) => 3;
            exps.Add(new KeyValuePair<String, Expression>("a => 3", e1));
            e1 = (Int32 a) => a;
            exps.Add(new KeyValuePair<string, Expression>("a => a", e1));
            Expression<Func<Int32, Int32, Int32>> ex2 = (Int32 a, Int32 b) => a + b;
            exps.Add(new KeyValuePair<string, Expression>("(a, b) => a + b", ex2));
            return exps;
        }

        private void listBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedValue != null)
            {
                visitor.Visit(treeView1, (Expression)listBox1.SelectedValue);
            }

        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            propertyGrid1.SelectedObject = e.Node.Tag;
            PrepareDynamicExecution(e.Node.Tag as LambdaExpression);
        }

        private List<TextBox> txtBoxes = new List<TextBox>();
        private void PrepareDynamicExecution(LambdaExpression ex)
        {
            lstParameters.Items.Clear();
            if (ex == null)
            {
                gbDynamic.Height = 0;
                return;
            }
            else
            {
                gbDynamic.Height = 150;
            }
            foreach (ParameterExpression p in ex.Parameters)
            {
                ListViewItem lvi = lstParameters.Items.Add(p.Name);
                lvi.SubItems.Add("Not Set");
                lvi.Tag = p;
            }
        }

        private void btnSetValue_Click(object sender, EventArgs e)
        {
            if (lstParameters.SelectedIndices.Count != 1) return;
            ParameterExpression p = (ParameterExpression)lstParameters.SelectedItems[0].Tag;
            ParameterSetter setter = new ParameterSetter(p);
            if (setter.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                lstParameters.SelectedItems[0].SubItems[1].Tag = setter.SelectedValue;
                lstParameters.SelectedItems[0].SubItems[1].Text = setter.SelectedValue.ToString();
            }
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            LambdaExpression ex = treeView1.SelectedNode.Tag as LambdaExpression;
            if (ex == null) return;
            Delegate d = ex.Compile();
            Object[] parameters = new Object[lstParameters.Items.Count];
            for (Int32 I = 0; I < ex.Parameters.Count; ++I)
            {
                parameters[I] = lstParameters.Items[I].SubItems[1].Tag;
            }
            txtResult.Text = d.DynamicInvoke(parameters).ToString();
        }


    }
}
