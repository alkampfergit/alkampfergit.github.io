﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Windows.Forms;

namespace LinqTest
{
    class DumpVisitor : ExpressionVisitor
    {
        private TreeView tv;
        private TreeNode Current { get { return nodeStack.Peek(); } }
        private TreeNode root;
        public void Visit(TreeView tv, Expression ex)
        {
            this.tv = tv;
            tv.Nodes.Clear();
            root = tv.Nodes.Add(ex.ToString());
            nodeStack.Push(root);
            Visit(ex);
        }

        /// <summary>
        /// The complete expression stack visited
        /// </summary>
        private Stack<TreeNode> nodeStack = new Stack<TreeNode>();
        /// <summary>
        /// Visit a node, append the node to the tree.
        /// </summary>
        /// <param name="exp"></param>
        /// <returns></returns>
        public override System.Linq.Expressions.Expression Visit(
            System.Linq.Expressions.Expression exp)
        {
            //Add a new node into the stack, attach the node with the topm
            nodeStack.Push(
                nodeStack.Peek()
                .Nodes.Add(exp.NodeType.ToString()));
            Current.Tag = exp;
            Expression result = base.Visit(exp);
            nodeStack.Pop();
            return result;
        }

        /// <summary>
        /// When a node is a parameter the base function calls Visit Parameter
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        protected override Expression VisitParameter(ParameterExpression p)
        {
            Current.Text = String.Format("{0} name={1}",Current.Text, p.Name);
            return base.VisitParameter(p);
        }


       
    }
}
