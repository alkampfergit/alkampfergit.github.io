﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Windows.Forms;

namespace LinqTest
{
    class DumpVisitor : ExpressionVisitor
    {
        private TreeView tv;
        private TreeNode current;
        public void Visit(TreeView tv, Expression ex)
        {
            this.tv = tv;
            tv.Nodes.Clear();
            Visit(ex);
        }

        //protected override System.Linq.Expressions.Expression VisitUnary(System.Linq.Expressions.UnaryExpression u)
        //{
        //    Console.WriteLine("unary:{0}", u.ToString());
        //    return base.VisitUnary(u);
        //}

        public override System.Linq.Expressions.Expression Visit(System.Linq.Expressions.Expression exp)
        {
            current = tv.Nodes.Add(exp.NodeType.ToString());
            current.Tag = exp;
            return base.Visit(exp);
        }

        //protected override System.Linq.Expressions.Expression VisitLambda(
        //    System.Linq.Expressions.LambdaExpression lambda)
        //{
        //    Console.WriteLine("lambda:{0}", lambda);
        //    return base.VisitLambda(lambda);
        //}

        //protected override System.Linq.Expressions.Expression VisitMemberAccess(System.Linq.Expressions.MemberExpression m)
        //{
        //    Console.WriteLine("MemberAccess:{0}", m.ToString());
        //    return base.VisitMemberAccess(m);
        //}

        //protected override System.Linq.Expressions.Expression VisitMethodCall(
        //    System.Linq.Expressions.MethodCallExpression m)
        //{
        //    Console.WriteLine("MethodCall:{0}", m.ToString());
        //    return base.VisitMethodCall(m);
        //}

        //protected override System.Linq.Expressions.Expression VisitInvocation(
        //    System.Linq.Expressions.InvocationExpression iv)
        //{
        //    Console.WriteLine("Invocation:{0}", iv);
        //    return base.VisitInvocation(iv);
        //}

        //protected override System.Linq.Expressions.Expression VisitBinary(
        //    System.Linq.Expressions.BinaryExpression b)
        //{
        //    Console.WriteLine("binary:{0}", b.ToString());
        //    return base.VisitBinary(b);
        //}
    }
}
