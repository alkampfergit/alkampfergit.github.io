﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Windows.Forms;

namespace LinqTest
{
    public partial class Dumper : Form
    {
        private DumpVisitor visitor = new DumpVisitor();
        public Dumper()
        {
            InitializeComponent();
            List<KeyValuePair<String, Expression>> exps = 
new List<KeyValuePair<string, Expression>>();
            Expression<Func<Int32, Int32>> e1 = (Int32 a) => 3;
            exps.Add(new KeyValuePair<String, Expression>("a => 3", e1));

            listBox1.DataSource = exps;
       }

        private void listBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedValue != null)
            {
                visitor.Visit(treeView1, (Expression)listBox1.SelectedValue);
            }

        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            propertyGrid1.SelectedObject = e.Node.Tag;
        }
    }
}
