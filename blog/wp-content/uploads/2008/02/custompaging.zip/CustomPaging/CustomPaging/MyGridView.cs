using System;
using System.Collections;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace CustomPaging {
	public class MyGridView : GridView  {

		public Int32 RecordCount {
			get { return (Int32) (ViewState[RecordCountKey] ?? 0); }
			set { ViewState[RecordCountKey] = value;}
		}
		private const String RecordCountKey = "RecCount";

		public Int32 CustomPageIndex {
			get { return (Int32)(ViewState[CustomPageIndexKey] ?? 0); }
			set { ViewState[CustomPageIndexKey] = value; }
		}
		private const String CustomPageIndexKey = "CustomPageIndexKey";

		protected override void InitializePager(GridViewRow row, int columnSpan, PagedDataSource pagedDataSource) {
			pagedDataSource.AllowPaging = true;
			pagedDataSource.AllowCustomPaging = true;
			//pagedDataSource.AllowServerPaging = true;
			pagedDataSource.VirtualCount = RecordCount;
			pagedDataSource.CurrentPageIndex = CustomPageIndex;
			base.InitializePager(row, columnSpan, pagedDataSource);
		}
	}
}
