using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Data.SqlClient;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace CustomPaging {
	public partial class _Default : System.Web.UI.Page {


		protected void Page_Load(object sender, EventArgs e) {
			if (!this.IsPostBack)
				DoBind();
		}

		private Int32 GetCount() {
			using (SqlConnection conn = new SqlConnection("server=localhost\\sql2000;Integrated Security=SSPI;Database=Northwind")) {
				using (SqlCommand c = conn.CreateCommand()) {
					conn.Open();
					c.CommandText = "select count(*) from Customers;";
					c.CommandType = CommandType.Text;
					return (Int32)c.ExecuteScalar();
				}
			}
		}

		private String PrepareQuery(String orderClause, Boolean directionAscending, Int32 pageIndex, Int32 pagesize, Int32 recCount) {
			Int32 numOfRecToReturn = pagesize;
			Int32 pageWidth = pagesize * (pageIndex + 1);
			if (pageWidth > recCount) {
				numOfRecToReturn -= (pageWidth - recCount);
			}
			return String.Format(
				@" sp_executesql N'
					select * from
					  (select top {0} * from 
						(select top {1} * from Customers order by {2} {3}) a
					  order by {2} {4}) b
					order by {2} {3}';",
				numOfRecToReturn,
				pageWidth,
				orderClause,
				directionAscending ? "ASC" : "DESC",
				directionAscending ? "DESC" : "ASC");
		}

		public String CurrentOrder {
			get { return (String)(ViewState[CurrentOrderKey] ?? "CustomerId"); }
			set { ViewState[CurrentOrderKey] = value; }
		}
		private const String CurrentOrderKey = "CurOrder";

		public Boolean AscendingOrder {
			get { return (Boolean)(ViewState[AscendingOrderKey] ?? true); }
			set { ViewState[AscendingOrderKey] = value; }
		}
		private const String AscendingOrderKey = "AscendingOrder";

		private void DoBind() {
			Int32 count = GetCount();
			String Query =
				PrepareQuery(CurrentOrder, AscendingOrder, MyGridView1.CustomPageIndex, MyGridView1.PageSize, count);
			using (SqlDataAdapter da = new SqlDataAdapter(Query, "server=localhost\\sql2000;Integrated Security=SSPI;Database=Northwind")) {
				DataSet ds = new DataSet();
				da.Fill(ds, "Customers");
				MyGridView1.RecordCount = count;
				MyGridView1.DataSource = ds.Tables[0].DefaultView;
				MyGridView1.DataBind();
			}
		}

		protected void MyGridView1_PageIndexChanging(object sender, GridViewPageEventArgs e) {
			MyGridView1.CustomPageIndex = e.NewPageIndex;
			DoBind();
		}

		protected void MyGridView1_OnSorting(object sender, GridViewSortEventArgs e) {
			if (String.Compare(CurrentOrder, e.SortExpression, true) == 0) {
				AscendingOrder = !AscendingOrder;
			}
			else {
				CurrentOrder = e.SortExpression;
				AscendingOrder = true;
			}

			DoBind();
		}
	}
}
