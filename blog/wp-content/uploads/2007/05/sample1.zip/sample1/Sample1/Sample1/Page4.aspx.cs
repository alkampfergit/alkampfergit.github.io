using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Sample1 {
	public partial class Page4 : System.Web.UI.Page, DomainLogic.IPageAddition {
		protected void Page_Load(object sender, EventArgs e) {

		}

		#region IPageAddition Members

		public void SetError(string errorString) {
			lblError.Text = errorString;
			lblError.Visible = true;
		}

		public void SetResult(string resultValue) {
			txtResult.Text = resultValue;
		}

		#endregion

		protected void Button1_Click(object sender, EventArgs e) {
			DomainLogic.Domain3.PerformAdd(TextBox1.Text, TextBox2.Text, this); 
		}
	}
}
