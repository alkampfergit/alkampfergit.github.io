using System;
using System.Collections.Generic;
using System.Text;

namespace DomainLogic {
	public class Domain2 {

		public static Int32 Add(Int32 addendo1, Int32 addendo2) {
			return addendo1 + addendo2;
		}

		public static String ValidateInput(
			String addendo1, String addendo2) {
			Int32 num;
			String result = String.Empty;
			if (!Int32.TryParse(addendo1, out num)) {
				result = "Primo addendo errato";
			}
			if (!Int32.TryParse(addendo2, out num)) {
				result += " Secondo addendo errato";
			}
			return result;
		}
	}
}
