using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;

namespace UnitTest {

	[TestFixture] 
	public class TestPage2Logic {

		[Test]
		public void TestAdd() {
			Assert.AreEqual(10, DomainLogic.Domain.Add(7, 3)); 
		}
	}
}
