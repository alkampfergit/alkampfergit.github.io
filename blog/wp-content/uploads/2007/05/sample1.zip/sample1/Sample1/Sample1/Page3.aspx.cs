using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Sample1 {
	public partial class Page3 : System.Web.UI.Page {
		protected void Page_Load(object sender, EventArgs e) {

		}

		protected void Button1_Click(object sender, EventArgs e) {
			if (ValidateInput()) {
				TextBox3.Text = DomainLogic.Domain2.Add(
					Int32.Parse(TextBox1.Text),
					Int32.Parse(TextBox2.Text)).ToString();
			}
			else {
				TextBox3.Text = String.Empty;
			}
		}

		private Boolean ValidateInput() {

			lblError.Text = DomainLogic.Domain2.ValidateInput(
				TextBox1.Text, TextBox2.Text);
			return String.IsNullOrEmpty(lblError.Text);
		}
	}
}
