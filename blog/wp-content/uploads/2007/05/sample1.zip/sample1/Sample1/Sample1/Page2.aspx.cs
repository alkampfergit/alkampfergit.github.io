using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Sample1 {
	public partial class Page2 : System.Web.UI.Page {
		protected void Page_Load(object sender, EventArgs e) {

		}

		protected void Button1_Click(object sender, EventArgs e) {
			if (ValidateInput()) {
				TextBox3.Text = DomainLogic.Domain.Add(
					Int32.Parse(TextBox1.Text),
					Int32.Parse(TextBox2.Text)).ToString();
			}
			else {
				TextBox3.Text = String.Empty;
			}
		}

		private Boolean ValidateInput() {
			Int32 num;
			lblError.Text = String.Empty;
			if (!Int32.TryParse(TextBox1.Text, out num)) {
				lblError.Text = "Primo addendo errato";
			}
			if (!Int32.TryParse(TextBox2.Text, out num)) {
				lblError.Text += " Secondo addendo errato";
			}
			return String.IsNullOrEmpty(lblError.Text);
		}
	}
}
