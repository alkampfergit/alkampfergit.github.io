using System;
using System.Collections.Generic;
using System.Text;

namespace DomainLogic {
	public static class Domain3 {

		public static void PerformAdd(
			String addendo1, 
			String addendo2, 
			IPageAddition page) {

			Int32 add1, add2;
			String errorString = String.Empty;
			if (!Int32.TryParse(addendo1, out add1)) {
				errorString = "Primo addendo errato";
			}
			if (!Int32.TryParse(addendo2, out add2)) {
				errorString += " Secondo addendo errato";
			}
			if (String.IsNullOrEmpty(errorString)) {
				page.SetResult((add1 + add2).ToString());
			}
			else {
				page.SetResult("");
				page.SetError(errorString); 
			}
		}
	}
}
