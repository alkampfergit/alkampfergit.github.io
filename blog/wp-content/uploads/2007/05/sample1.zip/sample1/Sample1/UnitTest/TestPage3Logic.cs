using NUnit.Framework;
using NUnit.Framework.Constraints; 
using System;

namespace UnitTest {

	[TestFixture]
	public class TestNameTests {

		[Test]
		public void TestAdd() {
			Assert.AreEqual(10, DomainLogic.Domain.Add(7, 3));
		}

		[Test]
		public void TestValidation() {
			Assert.That(
				DomainLogic.Domain2.ValidateInput("56", "56"), 
				new EmptyConstraint());
		}

		[Test]
		public void TestValidationWrong1() {
			Assert.That(
				DomainLogic.Domain2.ValidateInput("56f", "56"),
				new NotConstraint(
					new NUnit.Framework.Constraints.EmptyConstraint()));
		}

		[Test]
		public void TestValidationWrong2() {
			Assert.That(
				DomainLogic.Domain2.ValidateInput("56", "56t"),
				new NotConstraint(
					new NUnit.Framework.Constraints.EmptyConstraint()));
		}
	}
}
