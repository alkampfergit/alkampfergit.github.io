using NUnit.Framework;
using Rhino.Mocks; 
using System;

namespace UnitTests {
	[TestFixture]
	public class TestPage4Logic {

		[Test]
		public void TestGood() {
			MockRepository rep = new MockRepository();
			DomainLogic.IPageAddition ipa = rep.CreateMock<DomainLogic.IPageAddition>();
			ipa.SetResult("15");
			rep.ReplayAll();
			DomainLogic.Domain3.PerformAdd("12", "3", ipa);
			rep.VerifyAll();
		}

		[Test]
		public void TestWrong1() {
			MockRepository rep = new MockRepository();
			DomainLogic.IPageAddition ipa = rep.CreateMock<DomainLogic.IPageAddition>();
			ipa.SetResult("");
			ipa.SetError("");
			LastCall.IgnoreArguments();
			rep.ReplayAll();
			DomainLogic.Domain3.PerformAdd("fd", "3", ipa);
			rep.VerifyAll();
		}

		[Test]
		public void TestWrong2() {
			MockRepository rep = new MockRepository();
			DomainLogic.IPageAddition ipa = rep.CreateMock<DomainLogic.IPageAddition>();
			ipa.SetResult("");
			ipa.SetError("");
			LastCall.IgnoreArguments();
			rep.ReplayAll();
			DomainLogic.Domain3.PerformAdd("12", "32f", ipa);
			rep.VerifyAll();
		}

		[Test]
		public void TestWrong1TestMessage() {
			MockRepository rep = new MockRepository();
			DomainLogic.IPageAddition ipa = rep.CreateMock<DomainLogic.IPageAddition>();
			ipa.SetResult("");
			ipa.SetError("");
			LastCall.Constraints(
				Rhino.Mocks.Constraints.Text.StartsWith("Primo"));
			rep.ReplayAll();
			DomainLogic.Domain3.PerformAdd("1g2", "32", ipa);
			rep.VerifyAll();
		}
	}
}
