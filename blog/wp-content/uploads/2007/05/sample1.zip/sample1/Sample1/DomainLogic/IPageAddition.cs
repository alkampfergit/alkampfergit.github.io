using System;
using System.Collections.Generic;
using System.Text;

namespace DomainLogic {
	public interface IPageAddition {
		void SetError(String errorString);
		void SetResult(String resultValue);
	}
}
