using System;
using System.Collections.Generic;
using System.Text;

namespace DomainLogic {
	public static class Domain {

		public static Int32 Add(Int32 addendo1, Int32 addendo2) {
			return addendo1 + addendo2; 
		}

	}
}
