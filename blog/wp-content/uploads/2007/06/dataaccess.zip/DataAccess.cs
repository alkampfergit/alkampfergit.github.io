using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Data.Common;
using System.Data.SqlClient;
using Nablasoft.Helpers.Castle;
using Nablasoft.Helpers.Configuration;
using Nablasoft.Properties;
using System.Configuration;

namespace Nablasoft.Helpers {

	/// <summary>
	/// This class is used to automate execution of single command query. This structure
	/// is made based on great work of Ayende
	/// </summary>
	public static class DataAccess {

		#region Hanling of connection
		/// <summary>
		/// This is the main connection string, it is a 
		/// </summary>
		public static ConnectionStringSettings MainConnectionString {
			get {
				//return mOverrideConnectionString ?? ConfigurationManager.ConnectionStrings[cMainDatabaseName];
				return IoC.Resolve<IConfigurationHandler>().MainConnectionString;
			}
		}

		/// <summary>
		/// To know at runtime the format of the parameter we need to check the 
		/// <see cref="System.Data.Common.DbConnection.GetSchema(String)"/> method. 
		/// To cache the format we use a dictionary with command type as a key and
		/// string format as value.
		/// </summary>
		private static Dictionary<Type, String> mParametersFormat = new Dictionary<Type, String>();

		/// <summary>
		/// Gets the format of the parameter.
		/// </summary>
		/// <param name="command"></param>
		/// <returns></returns>
		private static String GetParameterFormat(DbCommand command) {
			if (!mParametersFormat.ContainsKey(command.GetType())) {
				mParametersFormat.Add(
					command.GetType(),
					command.Connection.GetSchema("DataSourceInformation")
						.Rows[0]["ParameterMarkerFormat"].ToString());
			}
			return mParametersFormat[command.GetType()];
		}
		#endregion

		#region Execution core

		/// <summary>
		/// This is the core execution function, it accept a simple functor that will accept a sqlcommand
		/// the command is created in the core of the function so it really care of all the standard
		/// burden of creating connection, creating transaction and enlist command into a transaction.
		/// </summary>
		/// <param name="functionToExecute">The delegates that really executes the command.</param>
		public static void Execute(VoidFunc<DbCommand, DbProviderFactory> functionToExecute) {
			DbProviderFactory factory = DbProviderFactories.GetFactory(
				MainConnectionString.ProviderName);
			using (DbConnection connection = factory.CreateConnection()) {
				connection.ConnectionString = MainConnectionString.ConnectionString;
				connection.Open();
				DbTransaction tx = connection.BeginTransaction();
				try {
					using (DbCommand command = factory.CreateCommand()) {
						command.Connection = connection;
						command.Transaction = tx;
						functionToExecute(command, factory);
					}
					tx.Commit();
				}
				catch {
					tx.Rollback();
					throw;
				}
				finally {
					tx.Dispose();
				}
			}
		}

		#endregion

		#region helper function
		/// <summary>
		/// This function Execute a command, it accepts a function with no parameter that
		/// Prepare a command to be executed. It internally use the <see cref="Nablasoft.Helpers.SqlServer.Execute"/>
		/// function that really executes the code.
		/// </summary>
		/// <typeparam name="T">return parameter type, it reflect the return type
		/// of the delegates</typeparam>
		/// <param name="functionToExecute">The function that prepares the command that should
		/// be executed with execute scalar.</param>
		/// <returns></returns>
		public static T ExecuteScalar<T>(VoidFunc<DbCommand, DbProviderFactory> functionToExecute) {
			T result = default(T);
			Execute(delegate(DbCommand command, DbProviderFactory factory) {
				functionToExecute(command, factory);
				result = (T)command.ExecuteScalar();
			});
			return result;
		}

		/// <summary>
		/// This function Execute a command, it accepts a function with no parameter that
		/// returns a generic type T. It internally use the <see cref="Nablasoft.Helpers.SqlServer.Execute"/>
		/// function that really executes the code.
		/// </summary>
		/// <typeparam name="T">return parameter type, it reflect the return type
		/// of the delegates</typeparam>
		/// <param name="functionToExecute">the function that access the database and 
		/// return a result of type T.</param>
		/// <returns></returns>
		public static T Execute<T>(Func<T, DbCommand, DbProviderFactory> functionToExecute) {
			T result = default(T);
			Execute(delegate(DbCommand command, DbProviderFactory factory) {
				result = functionToExecute(command, factory);
			});
			return result;
		}

		/// <summary>
		/// This is the function that permits to use a datareader without any risk
		/// to forget datareader open.
		/// </summary>
		/// <param name="commandPrepareFunction">The delegate should accepts 3 parameter, 
		/// the command to configure, a factory to create parameters, and finally another
		/// delegate of a function that returns the datareader.</param>
		public static void ExecuteReader(
			VoidFunc<DbCommand, DbProviderFactory, Func<IDataReader>> commandPrepareFunction) {

			Execute(delegate(DbCommand command, DbProviderFactory factory) {
				//The code to execute only assures that the eventually created datareader would be
				//closed in a finally block.
				IDataReader dr = null;
				try {
					commandPrepareFunction(command, factory,
											  delegate() {
												  dr = command.ExecuteReader();
												  return dr;
											  });
				}
				finally {
					if (dr != null) dr.Dispose();
				}
			});
		}

		/// <summary>
		/// This is the function that permits to use a datareader without any risk
		/// to forget datareader open.
		/// </summary>
		/// <param name="commandPrepareFunction"></param>
		public static void ExecuteDataset(
			VoidFunc<DbCommand, DbProviderFactory, Func<DataSet>> commandPrepareFunction) {

			Execute(delegate(DbCommand command, DbProviderFactory factory) {
				//The code to execute only assures that the eventually created datareader would be
				//closed in a finally block.
				using (DataSet ds = new DataSet()) {
					commandPrepareFunction(command, factory,
											  delegate() {
												  using (DbDataAdapter da = factory.CreateDataAdapter()) {
													  da.SelectCommand = command;
													  da.Fill(ds);
												  }
												  return ds;
											  });
				}

			});
		}

		#endregion

		#region Command filler and helpers

			/// <summary>
		/// 
		/// </summary>
		/// <param name="command"></param>
		/// <param name="factory"></param>
		/// <param name="type"></param>
		/// <param name="name"></param>
		/// <param name="value"></param>
		public static void AddParameterToCommand(
			DbCommand command,
			DbProviderFactory factory,
			System.Data.DbType type,
			String name,
			object value) {

			DbParameter param = factory.CreateParameter();
			param.DbType = type;
			param.ParameterName = String.Format(GetParameterFormat(command), name);
			param.Value = value;
			command.Parameters.Add(param);
		}	

		#endregion



	}
}

